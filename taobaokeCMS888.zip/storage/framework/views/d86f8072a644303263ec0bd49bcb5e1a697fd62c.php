
<?php $__env->startSection('head'); ?>
  <title><?php echo e($TDK['title']); ?></title>
  <meta name="keywords" content="<?php echo e($TDK['keywords']); ?>" />
  <meta name="description" content="<?php echo e($TDK['description']); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <!--底部选项卡-->
  <?php echo $__env->make('home.wx.layouts._foot_tab_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <div class="mui-content" id="home-index">
		  <!--幻灯片轮播-->
	    <?php echo $__env->make('home.wx.index._banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	    <!--搜索-->
      <?php echo $__env->make('home.wx.layouts._search_input', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	    <!--栏目导航-->
      <?php if(count($categorys)>0): ?>
	       <?php echo $__env->make('home.wx.index._category', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php endif; ?>

	    <!--品牌券-->
	    <?php echo $__env->make('home.wx.index._brand', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <!-- 优惠券分类 -->
      <?php echo $__env->make('home.wx.index._coupon_category', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	    <!--魔方导航-->
	    <!-- include('home.wx.index._magic') -->

	    <!--文章展示-->
	    <!-- include('home.wx.index._artical') -->

	    <!--优惠券商品-->
	    <?php echo $__env->make('home.wx.index._coupon', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <!--版权-->
      <?php echo $__env->make('home.wx.layouts._copy', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.wx.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>