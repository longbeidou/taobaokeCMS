
<?php $__env->startSection('head'); ?>
  <title><?php echo e($TDK['title']); ?></title>
  <meta name="keywords" content="<?php echo e($TDK['keywords']); ?>" />
  <meta name="description" content="<?php echo e($TDK['description']); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <!--底部选项卡-->
  <?php echo $__env->make('home.wx.layouts._foot_tab_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!-- 主界面不动、菜单移动 -->
  	<!-- 侧滑导航根容器 -->
  	<div class="mui-off-canvas-wrap mui-draggable mui-slide-in">
  	  <!-- 菜单容器 -->
      <?php echo $__env->make('home.wx.couponCategory._aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  	  <!-- 主页面容器 -->
  	  <div class="mui-inner-wrap">
  	    <!-- 主页面标题 -->
  	   <?php echo $__env->make('home.wx.couponCategory._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!--底部选项卡-->
        <?php echo $__env->make('home.wx.layouts._foot_tab_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  	    <div class="mui-content mui-scroll-wrapper">
  	       <div class="mui-scroll">
      	        <!-- 主界面具体展示内容 -->
      	        <div class="mui-row" style="font-size: 14px; padding: 6px 0px 4px; background-color:#fff; border-bottom:1px solid #ed2a7a;">
      	        	<div class="mui-col-xs-4 mui-text-center">
      	        		<a class="a-can-do" href="<?php echo e($currentUrl); ?>?search=<?php echo e($oldRequest['search']); ?>" <?php if(!empty($oldRequest['order']) && ( $oldRequest['order'] === 'sales_down' || $oldRequest['order'] === 'rate_down' ) ): ?> style="color: #000000;" <?php else: ?> style="color: #ed2a7a;" <?php endif; ?>>综合排序<span class="mui-icon mui-icon-arrowdown" style="font-size: 14px;"></span></a>
      	        	</div>
      	        	<div class="mui-col-xs-4 mui-text-center">
      	        		<a class="a-can-do" href="<?php echo e($currentUrl); ?>?order=sales_down&search=<?php echo e($oldRequest['search']); ?>" <?php if(!empty($oldRequest['order']) && $oldRequest['order'] === 'sales_down'): ?> style="color: #ed2a7a;" <?php else: ?> style="color: #000000;" <?php endif; ?>>销量排序<span class="mui-icon mui-icon-arrowdown" style="font-size: 14px;"></span></a>
      	        	</div>
      	        	<div class="mui-col-xs-4 mui-text-center">
      	        		<a class="a-can-do" href="<?php echo e($currentUrl); ?>?order=rate_down&search=<?php echo e($oldRequest['search']); ?>"  <?php if(!empty($oldRequest['order']) && $oldRequest['order'] === 'rate_down'): ?>  style="color: #ed2a7a;" <?php else: ?> style="color: #000000;" <?php endif; ?>>优惠幅度<span class="mui-icon mui-icon-arrowdown" style="font-size: 14px;"></span></a>
      	        	</div>
      	        </div>
      	        <div style="height:10px; width:100%;"></div>
      	        <!--商品的详细列表-->
      		    <ul id="couponList" class="mui-table-view mui-grid-view">
      		        <?php echo $__env->make('home.wx.couponCategory._coupon', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  <?php if(empty($coupons->count())): ?>
                    <li class="mui-table-view-cell mui-media mui-col-xs-12">
                      <?php echo $__env->make('home.wx.couponCategory._tips_no_result', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </li>
                  <?php endif; ?>
      		    </ul>

      		    <!--分页-->
      		    <div class="mui-row mui-text-center" style="background-color: #FFFFFF; padding-top: 5px;">
                <?php echo $coupons->appends($oldRequest)->links('home.wx.pagination.default', $oldRequest); ?>

      		    </div>

      		    <!--猜你喜欢-->
      		    <div class="mui-row"  style="margin-top: 12px;">
      		    	<div class="mui-col-xs-4"><hr /></div>
      		        <div class="mui-col-xs-4 mui-text-center">
      		        	<span class="icon iconfont icon-wei-" style="font-size: 20px; color: #ed2a7a;"></span>
      		        	猜你喜欢
      		        </div>
      		        <div class="mui-col-xs-4"><hr /></div>
      		    </div>
      		    <div style="width: 100%; height: 5px;"></div>
      		    <ul class="mui-table-view mui-grid-view">
      		        <?php echo $__env->make('home.wx.couponCategory._guss_you_like_list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      		    </ul>
      		    <!--版权-->
      		    <?php echo $__env->make('home.wx.layouts._copy', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  	      </div>
  	    </div>
  	    <div class="mui-off-canvas-backdrop"></div>
  	  </div>
  	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.wx.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>