<?php

namespace App\Libraries\Alimama\top\domain;

/**
 * data
 * @author auto create
 */
class MapData
{

	/**
	 * password
	 **/
	public $model;
}
?>
