<header class="mui-bar mui-bar-nav">
    <!-- <a class="mui-action-back mui-icon mui-icon-left-nav mui-pull-left"></a>
    <h1 class="mui-title">超级搜券</h1> -->
    <div class="mui-row">
      <div class="mui-col-xs-1">
        <a class="mui-action-back mui-icon mui-icon-left-nav mui-pull-left"></a>
      </div>
      <div class="mui-col-xs-10">
        <h1 class="mui-title">超级搜券</h1>
      </div>
      <div class="mui-col-xs-1">
        <a class="mui-icon mui-action-menu mui-icon-home mui-pull-right a-can-do" href="/"></a>
      </div>
    </div>
</header>
