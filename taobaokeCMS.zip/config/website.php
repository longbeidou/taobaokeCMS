<?php

return [

	// 网站名称
	'name' => '我爱你一万年网',

	// 网站的域名
	'domain' => 'www.52010000.cn',

	// 网站统计代码
	'analysisJs' => '<script src="https://s19.cnzz.com/z_stat.php?id=1263097006&web_id=1263097006" language="JavaScript"></script>'
];
