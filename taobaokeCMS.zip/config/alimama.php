<?php

return [

	// 淘宝客api的appkey的值
	'appkey' => '24567452',

	// 淘宝客api的secretkey的值
	'secretKey' => '59023132261bb01eec7555738091eca5',

	// 淘宝账户的id
	'id' => '24234234234',

	// 好券清单API【导购】的必填adzone_id默认值
	'adzone_id' => '121822521',

	// 聚划算搜索api的默认pid参数
	'ju_items_search_pid' => 'mm_46591525_34308672_395542379',

	// 淘口令的标志字符数组
	'tpwdCode' => ['￥'],

	// 超级查询调取的券数量,参数为字符串
	'superSearchPageSize' => '25',
];
