<?php

return [

	// 淘宝客api的appkey的值
	'appkey' => '24567452',

	// 淘宝客api的secretkey的值
	'secretKey' => '59023132261bb01eec7555738091eca5',

	// 淘宝账户的id
	'id' => '24234234234',

	// 好券清单API【导购】的必填adzone_id默认值
	'adzone_id' => '121822521',
];
