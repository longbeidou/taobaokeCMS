<?php

namespace App\Libraries\Alimama\top\domain;

/**
 * 扩展属性
 * @author auto create
 */
class Extend
{

	/**
	 * empty
	 **/
	public $empty;
}
?>
