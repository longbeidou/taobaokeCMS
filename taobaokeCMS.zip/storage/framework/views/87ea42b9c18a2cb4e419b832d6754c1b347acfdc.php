<!DOCTYPE html>
<html>
<head>
    <?php echo $__env->make('admin.layouts._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body class="fixed-sidebar full-height-layout gray-bg" style="overflow:hidden">
    <div id="wrapper">
        <!--左侧导航开始-->
        <?php echo $__env->make('admin.layouts._left_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--左侧导航结束-->
        <!--右侧部分开始-->
        <div id="page-wrapper" class="gray-bg dashbard-1">
            <?php echo $__env->make('admin.layouts._right_top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('admin.layouts._right_tab', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('admin.layouts._right_content', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('admin.layouts._right_foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <!--右侧部分结束-->
        <!--右侧边栏开始-->
        <?php echo $__env->make('admin.layouts._right_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--右侧边栏结束-->
        <!--mini聊天窗口开始-->
        <!-- @ include('admin.layouts._small_chat_box') -->
    </div>
    <script src="/adminstyle/js/jquery.min.js?v=2.1.4"></script>
    <script src="/adminstyle/js/bootstrap.min.js?v=3.3.5"></script>
    <script src="/adminstyle/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="/adminstyle/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="/adminstyle/js/plugins/layer/layer.min.js"></script>
    <script src="/adminstyle/js/hplus.min.js?v=4.0.0"></script>
    <script src="/adminstyle/js/contabs.min.js" type="text/javascript"></script>
    <script src="/adminstyle/js/plugins/pace/pace.min.js"></script>
</body>

</html>
