<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li class="mui-table-view-cell mui-media mui-col-xs-4">
    <a class="a-can-do" href="<?php echo e(route('home.brandCoupons', $brand->id)); ?>">
        <img class="mui-media-object" src="<?php echo e($brand->image); ?>">
        <div class="mui-media-body">
          <p style="white-space: normal; max-height: 30px; overflow: hidden;"><?php echo e($brand->name); ?></p>
        </div>
    </a>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
