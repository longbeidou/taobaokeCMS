<?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td>
        <input type="checkbox" checked class="i-checks-notuse checkboxstyle" name="ids[]" value="<?php echo e($coupon['id']); ?>">
    </td>
    <td><img src="<?php echo e($coupon['image']); ?>" width="70px" /></td>
    <td style="max-width:200px;">
      <a href="<?php echo e($coupon['goods_info_link']); ?>" target="_blank">
      <?php echo e($coupon['goods_name']); ?>

      </a>
    </td>
    <td style="max-width:100px;"><?php echo e($coupon['category']); ?></td>
    <td><?php echo e($coupon['coupon_info']); ?></td>
    <td class="text-right"><?php echo e($coupon['price']); ?></td>
    <td class="text-right"><?php echo e($coupon['price_now']); ?></td>
    <td class="text-right"><?php echo e($coupon['rate_sales']); ?>%</td>
    <td class="text-right"><?php echo e($coupon['money']); ?></td>
    <td class="text-right"><?php echo e($coupon['sales']); ?></td>
    <td class="text-center">
      <?php if($coupon['flat'] == '天猫'): ?>
          <img src="/img/tmallicon.ico" />
      <?php else: ?>
          <img src="/img/taobaoicon.ico" />
      <?php endif; ?>
    </td>
    <td class="text-center">
      <a href="<?php echo e(route('admin.coupons.deleteById', $coupon['id'])); ?>"><i title="删除" class="fa fa-close text-danger"></i></a> |
      <?php if($coupon['is_recommend'] == 0): ?>
      <a href="<?php echo e(route('admin.coupons.recommendById', $coupon['id'])); ?>"><i title="推荐商品" class="fa fa-thumbs-up text-navy"></i></a> |
      <?php endif; ?>
      <?php if($coupon['is_recommend'] == 1): ?>
      <a href="<?php echo e(route('admin.coupons.notRecommendById', $coupon['id'])); ?>"><i title="取消推荐" class="fa fa-thumbs-down text-danger"></i></a> |
      <?php endif; ?>
      <?php if($coupon['is_show'] == 0): ?>
      <a href="<?php echo e(route('admin.coupons.showById', $coupon['id'])); ?>"><i title="前台显示商品" class="fa fa-toggle-on text-navy"></i></a> |
      <?php endif; ?>
      <?php if($coupon['is_show'] == 1): ?>
      <a href="<?php echo e(route('admin.coupons.notShowById', $coupon['id'])); ?>"><i title="取消前台商品显示" class="fa fa-toggle-off text-danger"></i></a>
      <?php endif; ?>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
