<ul class="mui-table-view mui-grid-view mui-grid-9">
  <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3">
      <a class="a-can-do" href="<?php echo e($category['link']); ?>">
          <img src="<?php echo e($category['image_small']); ?>" width="41px" height="41px" alt="" />
          <div class="mui-media-body"><?php echo e($category['name']); ?></div>
      </a>
  </li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- <li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3">
    <a href="#">
        <span class="mui-icon mui-icon-email"><span class="mui-badge mui-badge-red">5</span></span>
        <div class="mui-media-body">Email</div>
    </a>
</li> -->
</ul>
<div style="width: 100%; height: 10px;"></div>
