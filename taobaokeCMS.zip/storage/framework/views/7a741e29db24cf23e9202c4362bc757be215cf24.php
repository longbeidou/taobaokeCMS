<aside class="mui-off-canvas-left" id="offCanvasSide">
  <div class="mui-scroll-wrapper">
    <div class="mui-scroll" style="padding: 10px;">
      <!-- 菜单具体展示内容 -->
      <div class="mui-row">
        <!--商品分类-->
        <div class="mui-col-xs-12">
          <span class="nav-title" >
            <i class="icon iconfont icon-shangpin1" style="font-size: 24px;"></i>
            商品分类
          </span>
        </div>
        <div class="mui-col-xs-4" style="padding: 2px;">
          <a href="<?php echo e(route('home.coupon')); ?>" class="mui-btn a-can-do" style="width: 100%;">全部商品</a>
        </div>
        <?php $__currentLoopData = $couponCategorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $couponCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="mui-col-xs-4" style="padding: 2px;">
          <a href="<?php echo e(route('home.coupon', $couponCategory->id)); ?>" class="mui-btn a-can-do" style="width: 100%;"><?php echo e($couponCategory->category_name); ?></a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div style="width:100%; height: 25px; padding-top: 5px;"><hr style="border: 1px dotted #ed2a7a;" /></div>
      <!--导航-->
      <div class="mui-row">
        <div class="mui-col-xs-12">
          <span class="nav-title" >
            <i class="icon iconfont icon-daohang" style="font-size: 24px;"></i>
            导航
          </span>
        </div>
        <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="mui-col-xs-4" style="padding: 2px;">
          <a href="<?php echo e($category['link']); ?>" class="mui-btn a-can-do" style="width: 100%;"><?php echo e($category['name']); ?></a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
</aside>
