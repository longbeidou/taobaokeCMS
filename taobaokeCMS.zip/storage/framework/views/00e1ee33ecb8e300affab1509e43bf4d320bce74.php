<div class="mui-row">
  <div class="mui-col-xs-4"><hr /></div>
    <div class="mui-col-xs-4 mui-text-center">
      <span class="icon iconfont icon-brand" style="font-size: 24px; color: #ed2a7a;"></span>
      品牌券
    </div>
    <div class="mui-col-xs-4"><hr /></div>
</div>
<div class="mui-slider" id="index-mui-slider-brands">
    <div class="mui-slider-indicator mui-segmented-control mui-segmented-control-inverted">
        <a class="mui-control-item mui-active" href="#item0">全部</a>
        <?php $__currentLoopData = $brandCategorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$brandCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a class="mui-control-item " href="#item<?php echo e($key+1); ?>"><?php echo e($brandCategory->name); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div id="sliderProgressBar" class="mui-slider-progress-bar mui-col-xs-2"></div>
    <div class="mui-slider-group">
      <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$brandArr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
        if($key == 0) {
          $active = 'mui-active';
        } else {
          $active = '';
        }
      ?>
        <div id="item<?php echo e($key); ?>" class="mui-slider-item mui-control-content <?php echo e($active); ?>">
          <div class="mui-slider">
            <div class="mui-slider-group">
              <!--第一个内容区容器-->
              <div class="mui-slider-item">
                <!-- 具体内容 -->
                <ul class="mui-table-view mui-grid-view">
                  <?php $__currentLoopData = $brandArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="mui-table-view-cell mui-media mui-col-xs-4">
                        <a class="a-can-do" href="<?php echo e(route('home.brandCoupons', $brand->id)); ?>">
                            <img class="mui-media-object" src="<?php echo e($brand->image); ?>">
                            <div class="mui-media-body"><?php echo e($brand->name); ?></div>
                        </a>
                    </li>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<div style="width: 100%; height: 10px;"></div>
