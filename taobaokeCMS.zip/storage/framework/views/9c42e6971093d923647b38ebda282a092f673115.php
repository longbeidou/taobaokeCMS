<?php if($paginator->hasPages()): ?>
    <ul class="mui-pagination">
        
        <?php if($paginator->onFirstPage()): ?>
            <li class="mui-disabled"><span>首页</span></li>
            <li class="mui-disabled"><span>上一页</span></li>
        <?php else: ?>
            <li><a class="a-can-do" href="<?php echo e($elements[0][1]); ?>" rel="prev">首页</a></li>
            <li><a class="a-can-do" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">上一页</a></li>
        <?php endif; ?>

        <?php
            $e = end($elements);
            $lastUrl = end($e);
        ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <li><a class="a-can-do" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">下一页</a></li>
            <li><a class="a-can-do" href="<?php echo e($lastUrl); ?>" rel="next">末页</a></li>
        <?php else: ?>
            <li class="mui-disabled"><span>下一页</span></li>
            <li class="mui-disabled"><span>末页</span></li>
        <?php endif; ?>
    </ul>
<?php endif; ?>
