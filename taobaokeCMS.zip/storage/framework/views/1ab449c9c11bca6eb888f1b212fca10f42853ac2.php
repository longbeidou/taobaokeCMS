<div class="container" id="category-list">
  <div class="row">
    <div class="container">
      <ul class="list-inline">

        <?php
          if ( empty($requestId) ) {
            $active = 'active';
          } else {
            $active = '';
          }
        ?>
        <li class="<?php echo e($active); ?>"><a href="<?php echo e(route('home.coupon')); ?>">全部</a></li>
        <?php $__currentLoopData = $couponCategorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $couponcate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          if ($requestId == $couponcate->id) {
            $active = 'active';
          } else {
            $active = '';
          }
        ?>
        <li class="<?php echo e($active); ?>"><a href="<?php echo e(route('home.coupon', $couponcate->id)); ?>"><?php echo e($couponcate->category_name); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </ul>
    </div>
  </div>
</div>
