<div class="col-sm-4 goods-box">
  <div class="panel panel-default">
    <div class="panel-heading">
      <div class="row">
        <div class="col-sm-6"><h3><?php echo e($info['category_name']); ?></h3></div>
        <div class="col-sm-6 text-right">
          <a href="<?php echo e(route('home.coupon', $info['id'])); ?>" target="_blank"><i class="iconfont icon-jiantou2"></i>更多</a>
        </div>
      </div>
    </div>
    <div class="panel-body only-image">
      <div class="row">
        <?php $__currentLoopData = $info['coupons']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($key == 0): ?>
          <div class="col-sm-12 i-top">
            <a href="<?php echo e(route('home.couponInfo', $coupon->id)); ?>" title="<?php echo e($coupon->goods_name); ?>" target="_blank"><img data-src="<?php echo e($coupon->image); ?>" src="/img/loading.gif" alt="<?php echo e($coupon->goods_name); ?>"></a>
          </div>
          <?php else: ?>
          <?php break; ?>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-12 i-buttom">
          <?php $__currentLoopData = $info['coupons']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($key > 0 && $key < 4): ?>
            <div class="col-sm-4 i-left">
              <a href="<?php echo e(route('home.couponInfo', $coupon->id)); ?>" title="<?php echo e($coupon->goods_name); ?>" target="_blank"><img data-src="<?php echo e($coupon->image); ?>" src="/img/loading.gif" alt="<?php echo e($coupon->goods_name); ?>"></a>
            </div>
            <?php endif; ?>
            <?php if($key >= 4): ?>
            <?php break; ?>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </div>
</div>
