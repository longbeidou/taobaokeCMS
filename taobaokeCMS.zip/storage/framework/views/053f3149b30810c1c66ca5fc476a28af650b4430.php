
<?php $__env->startSection('head'); ?>
  <title><?php echo e($TDK['title']); ?></title>
  <meta name="keywords" content="<?php echo e($TDK['keywords']); ?>" />
  <meta name="description" content="<?php echo e($TDK['description']); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <!-- 主界面不动、菜单移动 -->
  	<!-- 侧滑导航根容器 -->
  	<div class="mui-off-canvas-wrap mui-draggable mui-slide-in">
  	  <!-- 菜单容器 -->
      <?php echo $__env->make('home.wx.couponCategory._aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  	  <!-- 主页面容器 -->
  	  <div class="mui-inner-wrap">
  	    <!-- 主页面标题 -->
  	   <?php echo $__env->make('home.wx.superSearch._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

       <!--底部搜索-->
       <?php echo $__env->make('home.wx.superSearch._foot_search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  	    <div class="mui-content mui-scroll-wrapper">
  	       <div class="mui-scroll" id="brand-tab-list">

             <?php if(count($errors) > 0): ?>
               <?php echo $__env->make('home.wx.superSearch._errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
             <?php endif; ?>

             <?php if(empty($has_search)): ?>
              <!-- 超级搜索说明 -->
               <?php echo $__env->make('home.wx.superSearch._info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
             <?php endif; ?>

             <!-- 搜索的结果 -->
             <?php if(!empty($has_search)): ?>
               <?php echo $__env->make('home.wx.superSearch._result', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
             <?php endif; ?>

             <!--猜你喜欢-->
             <div class="mui-row"  style="margin-top: 12px;">
               <div class="mui-col-xs-4"><hr /></div>
                 <div class="mui-col-xs-4 mui-text-center">
                   <span class="icon iconfont icon-wei-" style="font-size: 20px; color: #ed2a7a;"></span>
                   猜你喜欢
                 </div>
                 <div class="mui-col-xs-4"><hr /></div>
             </div>
             <div style="width: 100%; height: 5px;"></div>
             <ul class="mui-table-view mui-grid-view">
                 <?php echo $__env->make('home.wx.couponCategory._guss_you_like_block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
             </ul>

             <!--版权-->
             <?php echo $__env->make('home.wx.layouts._copy', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
             <div class="mui-row" >
               <div class="col-xs-12" style="height:80px;"></div>
             </div>
  	      </div>
  	    </div>
  	    <div class="mui-off-canvas-backdrop"></div>
  	  </div>
  	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.wx.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>