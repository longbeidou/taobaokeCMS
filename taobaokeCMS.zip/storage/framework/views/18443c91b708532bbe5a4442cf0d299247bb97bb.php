

<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('headcss'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-sm-8 col-sm-offset-2">
    <?php echo $__env->make('admin.layouts.form._errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.layouts.form._tips', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="ibox float-e-margins">
        <div class="ibox-title">
            <h5>优惠券分类详情</h5>
            <div class="ibox-tools">
                <a class="dropdown-toggle" href="<?php echo e(route('couponCategorys.index')); ?>">
                    <i class="fa fa-list"></i> 优惠券分类列表
                </a>
            </div>
        </div>
        <div class="ibox-content">
          <div class="row form-body form-horizontal m-t">
            <div class="col-md-12 droppable sortable ui-droppable ui-sortable">

              <div class="col-md-12">
                  <div class="form-group">
                      <label class="col-sm-3 control-label">分类名称：</label>
                      <div class="col-sm-9">
                          <p class="form-control-static"><?php echo e($couponCategory->category_name); ?></p>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-3 control-label">排序：</label>
                      <div class="col-sm-9">
                          <p class="form-control-static"><?php echo e($couponCategory->order); ?></p>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-3 control-label">图片：</label>
                      <div class="col-sm-9">
                          <p class="form-control-static">
                            <img src="<?php echo e($couponCategory->image_small); ?>" style="max-height:50px;" alt="">
                          </p>
                      </div>
                  </div>
									<div class="form-group">
											<label class="col-sm-3 control-label">字体图标：</label>
											<div class="col-sm-9">
													<p class="form-control-static"><?php echo $couponCategory->font_icon; ?></p>
											</div>
									</div>
                  <div class="form-group">
                      <label class="col-sm-3 control-label">是否显示：</label>
                      <div class="col-sm-9">
                          <p class="form-control-static"><?php echo e($is_show); ?></p>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-3 control-label">商品组合条件：</label>
                      <div class="col-sm-9">
                        <?php echo $selfWhereView; ?>

                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-3 control-label">创建日期：</label>
                      <div class="col-sm-9">
                          <p class="form-control-static"><?php echo e($couponCategory->created_at); ?></p>
                      </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-3 control-label">修改日期：</label>
                      <div class="col-sm-9">
                          <p class="form-control-static"><?php echo e($couponCategory->updated_at); ?></p>
                      </div>
                  </div>
              </div>

              <div style="clear:both;"></div>
              <div class="hr-line-dashed"></div>

              <div class="form-group">
                  <label class="col-sm-3 control-label">关键词填写说明：</label>
                  <div class="col-sm-9">
                      <p class="form-control-static">
                        “%关键词%”表示关键词可以出现在任何位置；<br>
                        “关键词%”表示以”关键词“开头的句子；<br />
                        “%关键词”表示以”关键词“结尾的句子。<br />
                      </p>
                  </div>
              </div>

            </div>
          </div>
        </div><!-- ibox-content -->
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footJs'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.form.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>