<div id="slider" class="mui-slider" style="background-color: #FFFFFF;">
  <div class="mui-slider-group mui-slider-loop">
    <!-- 额外增加的一个节点(循环轮播：第一个节点是最后一张轮播) -->
    <div class="mui-slider-item mui-slider-item-duplicate">
      <?php if(empty($smallImages)): ?>
      <img src="<?php echo e($couponInfo->image); ?>">
      <?php else: ?>
      <img src="<?php echo e(route('image.index', end($smallImages))); ?>">
      <?php endif; ?>
    </div>
    <!-- 第一张 -->
    <div class="mui-slider-item">
      <img src="<?php echo e(route('image.index', $couponInfo->image_encrypt)); ?>">
    </div>
    <?php $__currentLoopData = $smallImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $smallImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="mui-slider-item">
      <img src="<?php echo e(route('image.index', $smallImage)); ?>">
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- 额外增加的一个节点(循环轮播：最后一个节点是第一张轮播) -->
    <div class="mui-slider-item mui-slider-item-duplicate">
      <img src="<?php echo e(route('image.index', $couponInfo->image_encrypt)); ?>">
    </div>
  </div>
  <div class="mui-slider-indicator">
    <div class="mui-indicator mui-active"></div>
    <?php $__currentLoopData = $smallImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $smallImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="mui-indicator"></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<script type="text/javascript">
//获得slider插件对象
var gallery = mui('#slider');
gallery.slider({
interval:1500//自动轮播周期，若为0则不自动播放，默认为0；
});
</script>
