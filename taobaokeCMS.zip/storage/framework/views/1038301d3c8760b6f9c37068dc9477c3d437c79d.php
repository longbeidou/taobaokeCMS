

<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('headcss'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-sm-6 col-sm-offset-3">
    <?php echo $__env->make('admin.layouts.form._errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.layouts.form._tips', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="ibox float-e-margins">
        <div class="ibox-title">
            <h5>banner详情</h5>
						<div class="ibox-tools">
							<a class="dropdown-toggle" href="<?php echo e(route('banners.index')); ?>">
									<i class="fa fa-list"></i> banner列表
							</a>
						</div>
        </div>
        <div class="ibox-content">
          <div class="row form-body form-horizontal m-t">
              <div class="row">
                  <div class="col-sm-3 text-right">
                    <strong>banner简介</strong>
                  </div>
                  <div class="col-sm-9">
                    <p><?php echo e($banner->name); ?></p>
                  </div>
              </div>
              <div class="row">
                  <div class="col-sm-3 text-right">
                    <strong>排序</strong>
                  </div>
                  <div class="col-sm-9">
                    <p><?php echo e($banner->order); ?></p>
                  </div>
              </div>
              <div class="row">
                  <div class="col-sm-3 text-right">
                    <strong>网址链接</strong>
                  </div>
                  <div class="col-sm-9">
                    <p>
                      <a href="<?php echo e($banner->link); ?>" target="_blank" class="btn btn-info btn-xs">查看</a>
                    </p>
                    <p><?php echo e($banner->link); ?></p>
                  </div>
              </div>
              <div class="row">
                  <div class="col-sm-3 text-right">
                    <strong>显示状态</strong>
                  </div>
                  <div class="col-sm-9">
                    <?php if($banner->is_show == 1): ?> <p class="text-info">显示</p> <?php endif; ?>
                    <?php if($banner->is_show == 0): ?> <p class="text-danger">不显示</p> <?php endif; ?>
                  </div>
              </div>
              <div class="row">
                  <div class="col-sm-3 text-right">
                    <strong>展示位置</strong>
                  </div>
                  <div class="col-sm-9">
										<?php if($banner->flat == 'wx'): ?>
										<p>移动端展示</p>
										<?php else: ?>
                    <p>PC端展示</p>
										<?php endif; ?>
                  </div>
              </div>
              <div class="row">
                  <div class="col-sm-3 text-right">
                    <strong>栏目创建时间</strong>
                  </div>
                  <div class="col-sm-9">
                    <p><?php echo e($banner->created_at); ?></p>
                  </div>
              </div>
              <div class="row">
                  <div class="col-sm-3 text-right">
                    <strong>栏目更新时间</strong>
                  </div>
                  <div class="col-sm-9">
                    <p><?php echo e($banner->updated_at); ?></p>
                  </div>
              </div>
              <div class="row">
                  <div class="col-sm-3 text-right">
                    <strong>图片</strong>
                  </div>
                  <div class="col-sm-9">
                    <p><img class="img-thumbnail"  style="max-width:400px; max-height:300px;" src="<?php echo e($banner->image); ?>" /></p>
                  </div>
              </div>

              <div style="clear:both;"></div>
              <div class="hr-line-dashed"></div>

          </div>
        </div><!-- ibox-content -->
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footJs'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.form.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>