<div class="col-sm-12 goods-box full-image-move">
  <div class="row title">
    <div class="col-sm-12 text-center">
      <h2>—— <?php echo e($info['category_name']); ?> ——</h2>
    </div>
  </div>
  <div class="row coupon">
    <div id="full-image-move" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <?php
          $m = count($info['coupons']) / 3;
        ?>
        <?php for($i=0; $i< $m; $i++): ?>
          <?php if($i == 0): ?>
          <li data-target="#full-image-move" data-slide-to="0" class="active"></li>
          <?php else: ?>
          <li data-target="#full-image-move" data-slide-to="<?php echo e($i); ?>" class=""></li>
          <?php endif; ?>
        <?php endfor; ?>
      </ol>
      <div class="carousel-inner" role="listbox">

        <?php for($i=0; $i<$m; $i++): ?>
          <?php if($i==0): ?>
          <div class="item active">
            <div class="row coupon-box">
              <?php $__currentLoopData = $info['coupons']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key < 3): ?>
                <div class="col-sm-4 i-left">
                  <a href="<?php echo e(route('home.couponInfo', $coupon->id)); ?>" target="_blank">
                    <div class="row image-box">
                      <div class="image">
                        <img src="<?php echo e($coupon->image); ?>" alt="<?php echo e($coupon->goods_name); ?>">
                      </div>
                      <h3 class="goods-name"><?php echo e($coupon->goods_name); ?></h3>
                      <div class="col-sm-6 i-price">
                        <h6 class="price">￥<?php echo e($coupon->price_now); ?> <del><small>￥<?php echo e($coupon->price); ?></small></del></h6>
                      </div>
                      <div class="col-sm-6 text-right i-save">
                        <h6 class="save">领券立省<strong><?php echo e($couponInfoPre->saveMoney($coupon->coupon_info, $coupon->price)); ?></strong>元</h6>
                      </div>
                    </div>
                  </a>
                </div>
                <?php else: ?>
                <?php break; ?>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
          <?php else: ?>
          <div class="item">
            <div class="row coupon-box">
              <?php $__currentLoopData = $info['coupons']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key >= $i*3 && $key < $i*3+3): ?>
                <div class="col-sm-4 i-left">
                  <a href="<?php echo e(route('home.couponInfo', $coupon->id)); ?>" target="_blank">
                    <div class="row image-box">
                      <div class="image">
                        <img src="<?php echo e($coupon->image); ?>" alt="<?php echo e($coupon->goods_name); ?>">
                      </div>
                      <h3 class="goods-name"><?php echo e($coupon->goods_name); ?></h3>
                      <div class="col-sm-6 i-price">
                        <h6 class="price">￥<?php echo e($coupon->price_now); ?> <del><small>￥<?php echo e($coupon->price); ?></small></del></h6>
                      </div>
                      <div class="col-sm-6 text-right i-save">
                        <h6 class="save">领券立省<strong><?php echo e($couponInfoPre->saveMoney($coupon->coupon_info, $coupon->price)); ?></strong>元</h6>
                      </div>
                    </div>
                  </a>
                </div>
                <?php endif; ?>
                <?php if( $key >= $i*3+3): ?>
                <?php break; ?>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
          <?php endif; ?>
        <?php endfor; ?>

      </div>

      <a class="carousel-control-left" href="#full-image-move" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      </a>
      <a class="carousel-control-right" href="#full-image-move" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      </a>
    </div>
  </div>
</div>
