<?php $__currentLoopData = $couponCategorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $couponCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td>
       <input type="checkbox"   name="ids[]" value="<?php echo e($couponCategory->id); ?>" style="width:20px; height:20px; " checked>
    </td>
    <td>
      <input type="number" min="0" max="99" step="1" name="order[<?php echo e($couponCategory->id); ?>]" value="<?php echo e($couponCategory->order); ?>" />
    </td>
    <td><a href="<?php echo e(route('home.coupon', $couponCategory->id)); ?>" target="_blank"><?php echo e($couponCategory->category_name); ?></a></td>
    <td class="text-center"><img src="<?php echo e($couponCategory->image_small); ?>" height="41px" /></td>
    <td class="text-center"><?php echo $couponCategory->font_icon; ?></td>
    <td class="text-center" style="color:"><?php echo e($goodsTotal[$couponCategory->id]); ?></td>
    <td><?php echo e($couponCategory->self_where); ?></td>
    <td class="text-center">
      <?php if($couponCategory->is_show == '1'): ?>
         <span style="color:green;">显示</span>
      <?php else: ?>
         <span style="color:red;">不显示</span>
      <?php endif; ?>
    </td>
    <td class="text-left">
        <a href="<?php echo e(route('couponCategorys.edit', $couponCategory->id)); ?>"><i class="fa fa-edit text-navy" title="编辑" style="color:green;"></i></a> |
        <a href="<?php echo e(route('couponCategorys.delete', $couponCategory->id)); ?>"><i class="fa fa-close text-navy" title="删除" style="color:red;"></i></a> <?php if($couponCategory->is_show == 1): ?> |
        <a href="<?php echo e(route('couponCategorys.notShow', $couponCategory->id)); ?>"><i class="fa fa-toggle-off text-navy" title="取消显示" style="color:red;"></i></a> | <?php endif; ?>
        <?php if($couponCategory->is_show == 0): ?> |
        <a href="<?php echo e(route('couponCategorys.isShow', $couponCategory->id)); ?>"><i class="fa fa-toggle-on text-navy" title="设置显示" style="color:green;"></i></a> |
        <?php endif; ?>
        <a href="<?php echo e(route('couponCategorys.show', $couponCategory->id)); ?>"><i class="fa fa-info-circle text-navy" title="查看详情" style="color:green;"></i></a>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
