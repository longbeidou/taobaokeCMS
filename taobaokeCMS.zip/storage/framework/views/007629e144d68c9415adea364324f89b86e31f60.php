
<?php $__env->startSection('head'); ?>
  <title><?php echo e($TDK['title']); ?></title>
  <meta name="keywords" content="<?php echo e($TDK['keywords']); ?>" />
  <meta name="description" content="<?php echo e($TDK['description']); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <!-- 提示收藏网址 -->
  <?php echo $__env->make('home.pc.index._top_search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- 导航 -->
  <?php echo $__env->make('home.pc.layouts._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!-- 商品分类列表部分开始 -->
  <?php echo $__env->make('home.pc.brand._brand_category', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!-- 品牌分类列表 -->
  <?php echo $__env->make('home.pc.brand._brand_list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!-- 还没逛够 开始 -->
  <div class="container" id="home-foot-recommend">
    <div class="row title">
      <div class="col-sm-12 text-center">
        <h2 style="margin-top:0px;">—— 精品推荐 ——</h2>
      </div>
    </div>
    <div class="row">
      <?php echo $__env->make('home.pc.layouts._recommend_col_3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
  </div>
  <!-- 还没逛够 结束 -->

  <!-- 底部宣传语 -->
  <?php echo $__env->make('home.pc.index._foot_say', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- 网址底部 -->
  <?php echo $__env->make('home.pc.layouts._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- 采用lazyload加载图片 -->
  <?php echo $__env->make('home.pc.layouts._lazyload_js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.pc.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>