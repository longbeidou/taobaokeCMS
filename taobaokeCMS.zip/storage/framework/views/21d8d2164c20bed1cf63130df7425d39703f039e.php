<div class="container" id="home-brand">
  <div class="col-sm-12 brand-category">
    <div class="row">
      <div class="col-sm-4">
        <h4>天猫淘宝品牌优惠券大全<small>知名品牌优惠券免费领取</small></h4>
      </div>
      <div class="col-sm-8 ">
          <ul class="nav nav-tabs pull-right" role="tablist">
            <?php $__currentLoopData = $brandCategorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$brandCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $key += 1; ?>
              <?php if($key == 1): ?>
              <li role="presentation" class="active"><a href="#banner<?php echo e($key); ?>" role="tab" data-toggle="tab" aria-controls="banner<?php echo e($key); ?>" aria-expanded="true"><?php echo e($brandCategory->name); ?></a></li>
              <?php else: ?>
              <li role="presentation" class=""><a href="#banner<?php echo e($key); ?>" role="tab" data-toggle="tab" aria-controls="banner<?php echo e($key); ?>" aria-expanded="false"><?php echo e($brandCategory->name); ?></a></li>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <li role="presentation" class=""><a href="<?php echo e(route('home.brands')); ?>" target="-_blank">更多</a></li>
          </ul>
      </div>
    </div>
  </div>
  <div class="col-sm-12">
    <div class="tab-content brand-content">
      <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($key == 0): ?>
        <div role="tabpanel" class="tab-pane fade active in" id="banner<?php echo e($key); ?>" aria-labelledby="home-tab">
          <ul class="list-inline">
            <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('home.brandCoupons', $b->id)); ?>"><img src="<?php echo e($b->image); ?>" alt="<?php echo e($b->name); ?>" /></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <?php else: ?>
        <div role="tabpanel" class="tab-pane fade" id="banner<?php echo e($key); ?>" aria-labelledby="profile-tab">
          <ul class="list-inline">
            <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('home.brandCoupons', $b->id)); ?>"><img src="<?php echo e($b->image); ?>" alt="<?php echo e($b->name); ?>" /></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
