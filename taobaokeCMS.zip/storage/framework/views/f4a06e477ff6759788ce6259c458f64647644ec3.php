
<?php $__env->startSection('head'); ?>
  <title><?php echo e($TDK['title']); ?></title>
  <meta name="keywords" content="<?php echo e($TDK['keywords']); ?>" />
  <meta name="description" content="<?php echo e($TDK['description']); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <!--底部搜索-->
  <?php echo $__env->make('home.wx.layouts._foot_tab_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <?php echo $__env->make('home.wx.aboutUs._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!-- 主界面不动、菜单移动 -->
  	<!-- 侧滑导航根容器 -->
  	<div id="content" class="mui-content">
      <?php echo $__env->make('home.wx.aboutUs._content', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.wx.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>