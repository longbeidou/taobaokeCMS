<div class="col-sm-4 goods-box">
  <div class="panel panel-default">
    <div class="panel-heading">
      <div class="row">
        <div class="col-sm-6"><h3><?php echo e($info['category_name']); ?></h3></div>
        <div class="col-sm-6 text-right">
          <a href="<?php echo e(route('home.coupon', $info['id'])); ?>" target="_blank"><i class="iconfont icon-jiantou2"></i>更多</a>
        </div>
      </div>
    </div>
    <div class="panel-body i-tian">
      <div class="row">
        <?php $__currentLoopData = $info['coupons']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($key>3): ?>
          <?php break; ?>
          <?php endif; ?>
        <div class="col-sm-6 coupon-box">
          <a href="<?php echo e(route('home.couponInfo', $coupon->id)); ?>" target="_blank">
            <div class="row coupon">
              <div class="col-sm-12 text-center image-box">
                <img data-src="<?php echo e($coupon->image); ?>" src="/img/loading.gif" alt="<?php echo e($coupon->goods_name); ?>">
              </div>
              <div class="col-sm-12 text-center">
                <h3 class="goods-name"><?php echo e($coupon->goods_name); ?></h3>
                <h4 class="price"><span>￥<?php echo e($coupon->price_now); ?></span><small><del>￥<?php echo e($coupon->price); ?></del></small></h4>
              </div>
            </div>
          </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
</div>
