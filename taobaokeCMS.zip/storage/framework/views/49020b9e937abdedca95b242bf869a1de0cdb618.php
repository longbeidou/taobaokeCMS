<!DOCTYPE html>
<html>
<head>
    <?php echo $__env->make('admin.layouts.form._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php $__env->startSection('headcss'); ?>
    <?php echo $__env->yieldSection(); ?>
</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <?php $__env->startSection('content'); ?>
        <?php echo $__env->yieldSection(); ?>
    </div>

    <?php echo $__env->make('admin.layouts.form._foot_js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php $__env->startSection('footJs'); ?>
    <?php echo $__env->yieldSection(); ?>
</body>

</html>
