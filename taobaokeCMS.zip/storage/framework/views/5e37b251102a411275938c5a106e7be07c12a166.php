<div id="slider" class="mui-slider" >
  <div class="mui-slider-group mui-slider-loop">
    <!-- 额外增加的一个节点(循环轮播：第一个节点是最后一张轮播) -->
    <?php if($banners->count()): ?>
    <div class="mui-slider-item mui-slider-item-duplicate">
      <a class="a-can-do" href="<?php echo e($banners->last()->link); ?>">
        <img src="<?php echo e($banners->last()->image); ?>">
      </a>
    </div>
    <?php endif; ?>
    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="mui-slider-item">
      <a class="a-can-do" href="<?php echo e($banner->link); ?>">
        <img src="<?php echo e($banner->image); ?>">
      </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- 额外增加的一个节点(循环轮播：最后一个节点是第一张轮播) -->
    <?php if($banners->count()): ?>
    <div class="mui-slider-item mui-slider-item-duplicate">
      <a class="a-can-do" href="<?php echo e($banners[0]->link); ?>">
        <img src="<?php echo e($banners[0]->image); ?>">
      </a>
    </div>
    <?php endif; ?>
  </div>
  <div class="mui-slider-indicator">
    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($key == 0): ?>
      <div class="mui-indicator mui-active"></div>
      <?php else: ?>
      <div class="mui-indicator"></div>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<div style="width: 100%; height: 10px;"></div>
