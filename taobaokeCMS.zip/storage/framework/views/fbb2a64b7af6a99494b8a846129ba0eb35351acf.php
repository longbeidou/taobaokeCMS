<div class="mui-scroll-wrapper mui-slider-indicator mui-segmented-control mui-segmented-control-inverted" style="background: #FFFFFF; border-bottom: 1px solid #efeff4;">
    <div class="mui-scroll">
        <?php $active = app('App\Presenters\WiewPresenter'); ?>
        <a href="<?php echo e(route('home.brands')); ?>" class="mui-control-item <?php echo e($active->muiActive(0, $id)); ?> a-can-do">全部</a>
        <?php $__currentLoopData = $AllBrandCategorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brandCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('home.brands', $brandCategory->id)); ?>" class="mui-control-item <?php echo e($active->muiActive($id, $brandCategory->id)); ?> a-can-do" href="<?php echo e($brandCategory->id); ?>"><?php echo e($brandCategory->name); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
