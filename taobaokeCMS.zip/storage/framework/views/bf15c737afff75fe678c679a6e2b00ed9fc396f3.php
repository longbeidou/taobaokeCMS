<div class="row J_mainContent" id="content-main">
    <iframe class="J_iframe" name="iframe0" width="100%" height="100%" src="<?php echo e(route('admin.dashbard.index')); ?>" frameborder="0" data-id="<?php echo e(route('admin.dashbard.index')); ?>" seamless></iframe>
</div>
