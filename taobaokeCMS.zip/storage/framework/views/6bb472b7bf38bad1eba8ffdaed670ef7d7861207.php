<?php if( session('success') ): ?>
  <div class="alert alert-success .alert-dismissible fade in">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
    <strong>成功：</strong>
    <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>
<?php if( session('info') ): ?>
  <div class="alert alert-info .alert-dismissible fade in">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
    <strong>提示：</strong>
    <?php echo e(session('info')); ?>

  </div>
<?php endif; ?>
<?php if( session('warning') ): ?>
  <div class="alert alert-warning .alert-dismissible fade in">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
    <strong>警告：</strong>
    <?php echo e(session('warning')); ?>

  </div>
<?php endif; ?>
<?php if( session('danger') ): ?>
  <div class="alert alert-danger .alert-dismissible fade in">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
    <strong>注意：</strong>
    <?php echo e(session('danger')); ?>

  </div>
<?php endif; ?>
