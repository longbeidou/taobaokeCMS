<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="renderer" content="webkit">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<title><?php echo $__env->yieldContent('title', '控制面板'); ?> - 后台管理系统</title>
<meta name="keywords" content="">
<meta name="description" content="">
<!--[if lt IE 8]>
<meta http-equiv="refresh" content="0;ie.html" />
<![endif]-->
<link rel="shortcut icon" href="/favicon.ico">
<link href="/adminstyle/css/bootstrap.min.css?v=3.3.5" rel="stylesheet">
<link href="/adminstyle/css/font-awesome.min.css?v=4.4.0" rel="stylesheet">
<link href="/adminstyle/css/animate.min.css" rel="stylesheet">
<link href="/adminstyle/css/style.min.css?v=4.0.0" rel="stylesheet">
<!-- <link rel="stylesheet" href="/css/selfIcon/iconfont.css"> -->
<link rel="stylesheet" href="//at.alicdn.com/t/font_581943_m5ux7ktvwj2u766r.css">
<link href="/wxstyle/css/main.css" rel="stylesheet"/>
