<div class="col-sm-8">
  <div class="" style="padding-left: 15px; padding-right: 15px;">
    <?php if(!empty($itemCouponsArr['items'])): ?>
    <div class="row coupon-info">
      <?php $__currentLoopData = $itemCouponsArr['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-sm-12" style="background-color: #fff; margin-bottom: 15px;">
        <div class="row" style="padding-top: 15px; padding-bottom: 15px; height: 240px;">
          <div class="col-sm-4 image-box">
            <a href="<?php echo e($item['pc_url']); ?>" target="_blank" class="goods-name">
              <img data-src="<?php echo e($item['pic_url_for_p_c']); ?>" src="/img/loading.gif" alt="<?php echo e($item['title']); ?>">
            </a>
          </div>
          <div class="col-sm-8">
            <div class="row">
              <div class="col-sm-12" style="height: 45px;">
                <a href="<?php echo e($item['pc_url']); ?>" target="_blank" class="goods-name">
                  <h2 style="line-height: 20px;"><?php echo e($item['title']); ?><?php echo e(time()); ?></h2>
                </a>
              </div>
              <div class="col-sm-9 price" style="padding-right: 0px;">
                聚划算价格￥<strong><?php echo e($item['act_price']); ?></strong>元 在售价￥<del><?php echo e($item['orig_price']); ?></del>元
              </div>
              <div class="col-sm-3 text-center" style="padding-left: 0px;">
                  <?php if($item['pay_postage'] ): ?>
                  <span style="color: #ed2a7a;">包邮免运费</span>
                  <?php else: ?>
                  <span style="color: #777;">邮费自理</span>
                  <?php endif; ?>
              </div>
              <div class="col-sm-12">
                <p style="margin-bottom: 0px;">
                  产品特点：
                  <?php $__currentLoopData = $item['item_usp_list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span style="color: #ed2a7a;"><?php echo e($list); ?></span> /
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
              </div>
              <div class="col-sm-8 text-center">
                <div class="row" style="padding-top: 20px;">
                  <div class="col-sm-1 text-center i-coupon-title">
                    优惠券
                  </div>
                  <div class="col-sm-8 text-center i-coupon-info" style="padding-top: 2px; padding-bottom: 11px;">
                    <h6><?php echo e($item['price_usp_list']); ?></h6>
                    <p class="text-center">开始展示时间:<?php echo e(date('Y-m-d H:i:s', substr($item['show_start_time'], 0, 10))); ?><br />开团结束时间:<?php echo e(date('Y-m-d H:i:s', substr($item['show_end_time'], 0, 10))); ?></p>
                  </div>
                  <div class="col-sm-3 text-center i-take">
                    <a class="btn btn-lg" href="<?php echo e($item['pc_url']); ?>" target="_blank">
                      马上<br>领券
                    </a>
                  </div>
                </div>
              </div>
              <div class="col-sm-4 text-center qrcode">
                <h6>手机淘宝扫码领券购买</h6>
                <img data-src="http://api.qrserver.com/v1/create-qr-code/?size=90x90&data=<?php echo e($item['wap_url']); ?>" src="/img/loading.gif" width="90px" alt="">
                <div class="big-qrcode">
                  <img data-src="http://api.qrserver.com/v1/create-qr-code/?size=150x150&data=<?php echo e($item['wap_url']); ?>" src="/img/loading.gif" width="90px" alt="">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
    <div class="row text-center page">
      <?php echo $__env->make('home.pc.superSearch._pagination_juhuasuan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
  </div>
</div>
