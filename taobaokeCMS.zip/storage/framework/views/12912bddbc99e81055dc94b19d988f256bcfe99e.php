<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td>
       <input type="checkbox"   name="ids[]" value="<?php echo e($brand->id); ?>" style="width:20px; height:20px; " checked>
    </td>
    <td>
      <input type="number" min="0" max="99" step="1" name="order[<?php echo e($brand->id); ?>]" value="<?php echo e($brand->order); ?>" />
    </td>
    <td><a href="<?php echo e(route('home.brandCoupons', $brand->id)); ?>" target="_blank"><?php echo e($brand->name); ?></a></td>
    <td class="text-center"><?php echo e($brand->total); ?></td>
    <td class="text-center"><?php echo e($idToNameArr[$brand->brand_category_id]); ?></td>
    <td class="text-center">
      <?php if(empty($brand->image)): ?>
      <img class="img-thumbnail" src="/adminstyle/img/nopicture.jpg" style="max-height:31px;" alt="">
      <?php else: ?>
      <img class="img-thumbnail" src="<?php echo e($brand->image); ?>" style="height:41px;" />
      <?php endif; ?>
    </td>
    <td class="text-center"><?php echo e($brand->keywords); ?></td>
    <td class="text-center">
      <?php if($brand->is_show == '1'): ?>
         <span style="color:green;">显示</span>
      <?php else: ?>
         <span style="color:red;">不显示</span>
      <?php endif; ?>
    </td>
    <td class="text-center">
        <a href="<?php echo e(route('brands.edit', $brand->id)); ?>"><i class="fa fa-edit text-navy" title="编辑" style="color:green;"></i></a> |
        <a href="<?php echo e(route('brands.delete', $brand->id)); ?>"><i class="fa fa-close text-navy" title="删除" style="color:red;"></i></a> <?php if($brand->is_show == 1): ?> |
        <a href="<?php echo e(route('brands.notShow', $brand->id)); ?>"><i class="fa fa-toggle-off text-navy" title="取消显示" style="color:red;"></i></a> | <?php endif; ?>
        <?php if($brand->is_show == 0): ?> |
        <a href="<?php echo e(route('brands.isShow', $brand->id)); ?>"><i class="fa fa-toggle-on text-navy" title="设置显示" style="color:green;"></i></a> |
        <?php endif; ?>
        <a href="<?php echo e(route('brands.show', $brand->id)); ?>"><i class="fa fa-info-circle text-navy" title="查看详情" style="color:green;"></i></a>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
