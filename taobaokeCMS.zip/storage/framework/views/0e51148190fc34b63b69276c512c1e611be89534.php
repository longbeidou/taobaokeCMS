<?php $__currentLoopData = $couponsRecommend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-sm-3 goods-box">
  <a href="<?php echo e(route('home.couponInfo', $coupon->id)); ?>" target="_blank">
    <div class="goods">
      <div class="img">
        <img data-src="<?php echo e($coupon->image); ?>" src="/img/loading.gif" alt="<?php echo e($coupon->goods_name); ?>">
      </div>
      <div class="info">
        <h5 class="card-title goods-name"><?php echo e($coupon->goods_name); ?></h5>
        <h5 class="card-title text-center goods-price">￥<?php echo e($coupon->price_now); ?> <small><del>￥<?php echo e($coupon->price); ?></del></small></h5>
      </div>
    </div>
  </a>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
