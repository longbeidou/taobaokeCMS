<div class="container" id="foot-say">
  <div class="row">
    <div class="col-sm-3 text-center">
      <i class="iconfont icon-gouwu3"></i>
      <span>品类齐全，轻松购物</span>
    </div>
    <div class="col-sm-3 text-center">
      <i class="iconfont icon-zhanwaisousuo"></i>
      <span>人工挑选，每日上新</span>
    </div>
    <div class="col-sm-3 text-center">
      <i class="iconfont icon-kefu3"></i>
      <span>客服在线，精致服务</span>
    </div>
    <div class="col-sm-3 text-center">
      <i class="iconfont icon-tuijiansel"></i>
      <span>天天特价，畅选无忧</span>
    </div>
  </div>
</div>
