<header class="container-fluid">
  @include('home.pc.layouts._tips_save_us')
  @include('home.pc.layouts._top_search')
</header>
