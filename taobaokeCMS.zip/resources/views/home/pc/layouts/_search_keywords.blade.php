<li><a href="{{ route('home.coupon.search') }}?search=帆布双肩背包" target="_blank">帆布双肩背包</a></li>
<li><a href="{{ route('home.coupon.search') }}?search=男士全机械表" target="_blank">男士全机械表</a></li>
<li><a href="{{ route('home.coupon.search') }}?search=潮流包包" target="_blank">潮流包包</a></li>
<li><a href="{{ route('home.coupon.search') }}?search=男士皮鞋" target="_blank">男士皮鞋</a></li>
<li><a href="{{ route('home.coupon.search') }}?search=面膜" target="_blank">面膜</a></li>
<li><a href="{{ route('home.coupon.search') }}?search=狗狗玩具" target="_blank">狗狗玩具</a></li>
