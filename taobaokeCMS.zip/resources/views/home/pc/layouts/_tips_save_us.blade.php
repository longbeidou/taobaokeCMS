<div class="row alert alert-warning alert-dismissible" role="alert" id="save">
  <div class="container text-center type="button" class="close" data-dismiss="alert" aria-label="Close"">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    <strong>提示!</strong> 按Ctrl + D,将本站放入收藏夹，优惠券信息一手掌握！
  </div>
</div>
