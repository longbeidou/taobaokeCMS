<footer class="container-fluid text-center" id="search-footer">
  <h6 style="margin-bottom: 5px;">copyright@2017-2018 四川龙琴科技有限公司 版权所有！</h6>
  <h6 style="margin-top: 5px; margin-bottom:5px;">备案号：{{ config('website.domain_beian') }}</h6>
</footer>
