<div id="taoKouLingInfo" style="display: none; position: fixed; z-index: 999; width: 80%; margin-left: 10%; margin-right: 10%; top: 30%;">
  <div style="width: 100%; height: 30px; text-align: center; background-color: #ed2a7a; border-top-right-radius: 30px; border-top-left-radius: 30px; border: 1px solid #ed2a7a;">
    <span style="line-height: 30px; font-size: 18px; color: #FFFFFF; font-weight: 800;">淘口令购买</span>
  </div>
  <div style="padding: 5px 20px; width: 100%; background-color: #FFFFFF; border: 1px solid #ed2a7a;">
    <div style="position: relative; width: 50%; z-index: 2; margin-left: 25%; top: 10px; padding: 2px; background-color: #EC971F; text-align: center;">
      <span style="font-size: 14px; line-height: 14px; color: #FFFFFF;">长按框内 > 复制</span>
    </div>
    <div style="border: 1px dashed #ed2a7a; padding: 20px 5px; position: relative; text-align: center;">
      <span style="font-size: 14px;  -webkit-user-select:auto;" id="kouLingCode">复制这条信息{{ $taoKouLing }}打开【手机淘宝】即可领取优惠券购买！</span>
    </div>
    <div id="kouLingDivBtn" style="position: relative; width: 30%; margin-left: 35%; bottom: 13px; padding: 2px; background-color: #ed2a7a; text-align: center;  border-radius: 14px;">
      <span id="kouLingBtn" class="kouLingBtn" data-clipboard-action="copy" data-clipboard-target="#kouLingCode" style="font-size: 14px; line-height: 14px; color: #FFFFFF;">一键复制</span>
    </div>
  </div>
  <div style="background-color: #FFFFFF; padding: 15px 10px; position: relative; bottom: 18px; border-bottom-right-radius: 30px; border-bottom-left-radius: 30px; border: 1px solid #ed2a7a; border-top: 0px;">
    <div style="font-size: 12px; background-color: #efefef; padding: 8px;">温馨提示： 手机无【手机淘宝】者，可选择浏览器购买方式哦~</div>
  </div>
</div>
