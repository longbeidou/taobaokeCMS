<div id="keFuInfo" style="display: none; position: fixed; z-index: 999; width: 80%; margin-left: 10%; margin-right: 10%; top: 15%;">
  <div style="width: 100%; height: 30px; text-align: center; background-color: #ed2a7a; border-top-right-radius: 30px; border-top-left-radius: 30px; border: 1px solid #ed2a7a;">
    <span style="line-height: 30px; font-size: 18px; color: #FFFFFF; font-weight: 800;">客服微信</span>
  </div>
  <div style="padding: 20px; width: 100%; background-color: #FFFFFF; border: 1px solid #ed2a7a; text-align: center;">
    <img src="/img/about/qcode_person.jpg" width="100%" style="border: 2px dashed #ed2a7a; padding: 0px;" />
  </div>
  <div style="background-color: #FFFFFF; text-align: center; padding: 10px 10px 15px 10px; position: relative; bottom: 18px; border-bottom-right-radius: 30px; border-bottom-left-radius: 30px; border: 1px solid #ed2a7a; border-top: 0px;">
    <div style="font-size: 12px; background-color: #efefef; padding: 8px;">加客服微信号，第一时间获取高额优惠券信息！</div>
  </div>
</div>
