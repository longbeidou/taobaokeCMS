<p>系统暂时没有收录到相关商品的优惠券</p>
<div class="mui-row">
  <div class="mui-col-xs-2">
    <p style="font-weight: 800; mui-pull-left">建议：</p>
  </div>
  <div class="mui-col-xs-12" style="text-align:left; padding-left:20px;">
    <p>1.请更换搜索词重新查询</p>
    <p>2.联系客服进行人工查询</p>
    <p>3.利用<a class="a-can-do" style="display:inline-block; padding: 0px 5px; margin: 0px 5px; background-color: rgba(237, 42, 122, 1); border-radius: 10px; color: #fff;" href="{{ route('home.superSearch.index') }}">超级搜索</a>查询淘宝网内部的全部优惠券商品</p>
  </div>
</div>
