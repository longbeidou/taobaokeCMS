<div class="mui-row">
  <div class="mui-col-xs-6">
    <a class="a-can-do" href="">
      <img src="http://placehold.it/400x300" width="100%" alt="" />
    </a>
  </div>
  <div class="mui-col-xs-6">
    <div class="mui-row" >
      <div class="mui-col-xs-12" style="margin-bottom: -5px;">
        <a class="a-can-do" href="">
          <img src="http://placehold.it/400x150" width="100%" alt="" />
        </a>
      </div>
    </div>
    <div class="mui-row">
      <div class="mui-col-xs-6">
        <a class="a-can-do" href="">
          <img src="http://placehold.it/400x300" width="100%" alt="" />
        </a>
      </div>
      <div class="mui-col-xs-6">
        <a class="a-can-do" href="">
          <img src="http://placehold.it/400x300" width="100%" alt="" />
        </a>
      </div>
    </div>
  </div>
</div>
