<div class="mui-row">
  <div class="mui-col-xs-4"><hr /></div>
    <div class="mui-col-xs-4 mui-text-center">
      <span class="mui-icon mui-icon-weixin"></span>
      选购技巧
    </div>
    <div class="mui-col-xs-4"><hr /></div>
</div>
<div style="width: 100%; height: 5px;"></div>
<div class="mui-slider">
  <div class="mui-slider-group">
    <!--第一个内容区容器-->
    <div class="mui-slider-item">
      <!-- 具体内容 -->
      <ul class="mui-table-view">
          <li class="mui-table-view-cell mui-media">
              <a class="a-can-do" href="javascript:;">
                  <img class="mui-media-object mui-pull-left" src="http://placehold.it/40x30">
                  <div class="mui-media-body">
                      幸福
                      <p class="mui-ellipsis">能和心爱的人一起睡觉，是件幸福的事情；可是，打呼噜怎么办？</p>
                  </div>
              </a>
          </li>
      </ul>
    </div>
    <!--第二个内容区-->
    <div class="mui-slider-item">
      <!-- 具体内容 -->
      <ul class="mui-table-view">
          <li class="mui-table-view-cell mui-media">
              <a href="javascript:;">
                  <img class="mui-media-object mui-pull-left" src="http://placehold.it/40x30">
                  <div class="mui-media-body">
                      幸福
                      <p class="mui-ellipsis">能和心爱的人一起睡觉，是件幸福的事情；可是，打呼噜怎么办？</p>
                  </div>
              </a>
          </li>
      </ul>
    </div>
  </div>
</div>
<div style="width: 100%; height: 10px;"></div>
