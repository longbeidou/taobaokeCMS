<div class="mui-row" style="margin-top: 5px;">
  <div class="mui-col-xs-12 mui-text-center">
    <p>Copyright©2017-2018 <br>版权归四川龙琴科技有限公司所有！</p>
  </div>
</div>
