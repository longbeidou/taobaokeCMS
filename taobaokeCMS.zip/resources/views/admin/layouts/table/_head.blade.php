<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>@yield('title', '表格')</title>
<meta name="keywords" content="">
<meta name="description" content="">
<link rel="shortcut icon" href="/favicon.ico">
<link href="/adminstyle/css/bootstrap.min.css?v=3.3.5" rel="stylesheet">
<link href="/adminstyle/css/font-awesome.min.css?v=4.4.0" rel="stylesheet">
<link href="/adminstyle/css/plugins/iCheck/custom.css" rel="stylesheet">
<link href="/adminstyle/css/animate.min.css" rel="stylesheet">
<link href="/adminstyle/css/style.min.css?v=4.0.0" rel="stylesheet">
