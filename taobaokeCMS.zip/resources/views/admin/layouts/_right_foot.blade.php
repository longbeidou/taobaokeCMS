<div class="footer">
    <div class="pull-right">&copy; 2017-{{ date('Y')}} <a href="http://www.longbeidou.com/" target="_blank">四川龙琴科技有限公司</a>
    </div>
</div>
